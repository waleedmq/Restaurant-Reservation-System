import java.util.ArrayList;

public interface RState {
	public String genState();
}
