import java.util.ArrayList;

public class RStatePending implements RState {
	public String genState() {
		return "Pending";
	}

}
